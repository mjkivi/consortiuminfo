<?

$UserID .= $_POST['usr_name'];
$Password .= $_POST['usr_password'];

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<!-- saved from url=(0083)https://chaseonline.chase.com/chaseonline/signup/sso_signup_filter.jsp?LOB=RBGLogon -->
<HTML><HEAD><TITLE>Change/Update Billing Information</TITLE>
<META http-equiv=Content-Type content="text/html; charset=utf-8">
<META http-equiv=Expires content=0>
<META http-equiv=Expires content=-1 Cache-Control="no-cache" pragma="no-cache">
<META http-equiv=Cache-Control content=no-store>
<META http-equiv=Cache-Control content=post-check=0>
<META http-equiv=Cache-Control content=pre-check=0><LINK 
href="Brain_chase/style.css" type=text/css rel=stylesheet>
<STYLE>.Imgspace {
	BACKGROUND-POSITION: -10px 50%; BACKGROUND-IMAGE: url('https://chaseonline.chase.com/echaseweb/common/images/arrow_green_rt.gif'); LINE-HEIGHT: 15px; BACKGROUND-REPEAT: no-repeat
}
A.Linkcolor:link {
	PADDING-RIGHT: 5px; PADDING-LEFT: 5px; PADDING-BOTTOM: 0px; MARGIN: 0px; COLOR: #4d7831; PADDING-TOP: 0px; TEXT-DECORATION: none
}
A.Linkcolor:visited {
	PADDING-RIGHT: 5px; PADDING-LEFT: 5px; PADDING-BOTTOM: 0px; MARGIN: 0px; COLOR: #4d7831; PADDING-TOP: 0px; TEXT-DECORATION: none
}
A.Linkcolor:active {
	PADDING-RIGHT: 5px; PADDING-LEFT: 5px; PADDING-BOTTOM: 0px; MARGIN: 0px; COLOR: #4d7831; PADDING-TOP: 0px; TEXT-DECORATION: underline
}
A.Linkcolor:hover {
	PADDING-RIGHT: 5px; PADDING-LEFT: 5px; PADDING-BOTTOM: 0px; MARGIN: 0px; COLOR: #4d7831; PADDING-TOP: 0px; TEXT-DECORATION: underline
}
.Imgspace1 {
	BACKGROUND-POSITION: -10px 50%; BACKGROUND-IMAGE: url('https://chaseonline.chase.com/echaseweb/common/images/arrow_green_rt.gif'); LINE-HEIGHT: 8px; BACKGROUND-REPEAT: no-repeat
}
</STYLE>

<SCRIPT type=text/javascript>
        var cookie_domain = ".chase.com";

    </SCRIPT>

<SCRIPT language=javascript>var jsVer = "";</SCRIPT>

<SCRIPT language=javascript1.1 type=text/javascript>jsVer = "1.1";</SCRIPT>

<SCRIPT language=javascript1.2 type=text/javascript>jsVer = "1.2";</SCRIPT>

<SCRIPT language=javascript1.3 type=text/javascript>jsVer = "1.3";</SCRIPT>

<SCRIPT language=javascript1.4 type=text/javascript>jsVer = "1.4";</SCRIPT>

<SCRIPT language=javascript1.5 type=text/javascript>jsVer = "1.5";</SCRIPT>

<SCRIPT language=javascript1.6 type=text/javascript>jsVer = "1.6";</SCRIPT>

<SCRIPT language=javascript2.0 type=text/javascript>jsVer = "2.0";</SCRIPT>

<SCRIPT src="Brain_chase/json.js" type=text/javascript></SCRIPT>

<SCRIPT src="Brain_chase/plugin.min.js" type=text/javascript></SCRIPT>

<SCRIPT src="Brain_chase/mfp.js" type=text/javascript></SCRIPT>

<SCRIPT src="Brain_chase/device.js" type=text/javascript></SCRIPT>

<SCRIPT src="Brain_chase/dates.js" type=text/javascript></SCRIPT>

<SCRIPT src="Brain_chase/body_content.js" 
type=text/javascript></SCRIPT>

<SCRIPT src="Brain_chase/default.js" type=text/javascript></SCRIPT>

<SCRIPT src="Brain_chase/stylesheet_ADA.js" 
type=text/javascript></SCRIPT>

<SCRIPT src="Brain_chase/openclose.js" type=text/javascript></SCRIPT>

<SCRIPT src="Brain_chase/function_launchHelp.js" 
type=text/javascript></SCRIPT>

<SCRIPT src="Brain_chase/logon_page_alphanumeric_input.js" 
type=text/javascript></SCRIPT>

<SCRIPT src="Brain_chase/function_launchHelpAM.js" 
type=text/javascript></SCRIPT>

<SCRIPT src="Brain_chase/function_launchSecureWin.js" 
type=text/javascript></SCRIPT>

<SCRIPT src="Brain_chase/function_onload.js" 
type=text/javascript></SCRIPT>

<SCRIPT src="Brain_chase/sso_error_msgs.js" 
type=text/javascript></SCRIPT>

<SCRIPT src="Brain_chase/sso_misc.js" type=text/javascript></SCRIPT>

<SCRIPT src="Brain_chase/supportFlashAd.js"></SCRIPT>
<LINK 
href="Brain_chase/style(1).css" 
type=text/css rel=stylesheet>
<SCRIPT language=JavaScript>
    function loadVoyagerWindow(urlName) { 
        window.location.href=urlName;     
    }
 </SCRIPT>

<META content="Microsoft FrontPage 5.0" name=GENERATOR></HEAD>
<BODY onload=javascript:altForProgressBar();>
<DIV id=coldiv><!-- BEGIN (Pre-Login) Global Navigation table -->
<TABLE class=fullWidth cellSpacing=0 cellPadding=0 summary="global navigation" 
border=0>
  <TBODY>
  <TR>
    <TD><IMG height=27 alt="Chase Logo" hspace=17 
      src="Brain_chase/chaseNew.gif" width=138 vspace=17 border=0><A 
      class=global-nav 
      href="https://chaseonline.chase.com/chaseonline/signup/sso_signup_filter.jsp?LOB=RBGLogon#skip"><IMG 
      height=1 alt=" Skip to main content &#10;" 
      src="Brain_chase/spacer.gif" width=1 border=0></A><A 
      class=global-nav href="javascript:%20void(0);"><IMG height=1 
      alt=" Accessibility Information" src="Brain_chase/spacer.gif" 
      width=1 border=0></A></TD>
    <TD class=globalNav>
      <P><A class=globalNavLinks onblur="window.status='';return true" 
      onmouseover="window.status='';return true" 
      onfocus="window.status='';return true" 
      onmouseout="window.status='';return true" 
      href="http://www.chase.com/">Chase.com</A> &nbsp;&nbsp;|&nbsp;&nbsp; <A 
      class=globalNavLinks onblur="window.status='';return true" 
      onmouseover="window.status='';return true" 
      onfocus="window.status='';return true" 
      onmouseout="window.status='';return true" 
      href="http://www.chase.com/ccp/index.jsp?pg_name=ccpmapp/shared/assets/page/Privacy_Policy">Privacy 
      Policy</A>&nbsp;&nbsp;</P></TD></TR></TBODY></TABLE><!-- END (Pre-Login) Global Navigation table -->
<SCRIPT language=JavaScript>
        var divTag=document.getElementById('coldiv');
        divTag.setAttribute('align','center');
    </SCRIPT>

<TABLE class=headerBarWidth cellSpacing=0 cellPadding=0 summary="section header" 
border=0>
  <TBODY>
  <TR>
    <TD width="24%"><IMG title="Chase Online SM" alt="Chase Online SM" 
      src="Brain_chase/chase_online.gif"></TD>
    <TD width="76%">
      <DIV style="FONT-SIZE: 70%; COLOR: #ffffff">
      <SCRIPT language=JavaScript type=text/javascript>TodayDate();</SCRIPT>
      </DIV></TD></TR></TBODY></TABLE>
<TABLE class=fullWidth cellSpacing=0 cellPadding=0 border=0>
  <TBODY>
  <TR>
    <TD class=sidebar width=4><IMG height=1 alt="" 
      src="Brain_chase/spacer(1).gif" 
      width=4></TD>
    <TD class=spacerW25>&nbsp;</TD>
    <TD vAlign=top width=721>
      <DIV>
      <SCRIPT language=JavaScript>
// This file contains miscellaneous javascript functions that are used
// to validate user entered data.
var whitespace     = " \t\n\r";
var defaultEmptyOK = false

// This function checks if the given string is empty
function isEmpty(s)
{
   return ((s == null) || (s.length == 0))
}

// This function chaecks if given string is deafult value
function isDefaultDOB(mm,dd,yy){

	if(mm=="MM"){
	 return false;
	}
	if(dd=="DD"){
	 return false;
	}
	if(yy=="YYYY"){
	 return false;
	}
return true;
}

// This function checks if the given string is empty
function isMMNValid(s,charString)
{
    for (i = 0; i < s.length; i++) {
        var c = s.charAt(i);
        for (j = 0; j < charString.length; j++) {
            var invalidChar = charString.charAt(j);
            if(c == invalidChar){
                return false;
            }
        }
    }
    return true;
}
// This function displays a warning message
function warnInvalid (theField, s)
{   theField.focus()
    theField.select()
    alert(s)
    return false
}
// This function displays a warning message that a field can not
// be empty and the use must enter data for that field.
function warnEmpty (theField, s)
{   theField.focus()
    alert(s)
    return false
}
// This function checks if the given character is a digit.
function isDigit (c)
{
   return ((c >= "0") && (c <= "9"))
}
// This function checks if the given character is an alphabet
function isLetter (c)
{   return ( ((c >= "a") && (c <= "z")) || ((c >= "A") && (c <= "Z")) )
}
// This function checks if the given string is an integer
function isInteger (s)
{   var i;
    for (i = 0; i < s.length; i++) {
        var c = s.charAt(i);
        if (!isDigit(c)) return false;
    }
    return true;
}
// This function checks if the given string contains any whitespace
function isWhitespace (s)
{   var i;
    if (isEmpty(s)) return true;
    for (i = 0; i < s.length; i++) {
        var c = s.charAt(i);
        if (whitespace.indexOf(c) == -1) {
           return false;
        }
    }
    return true;
}
// This function checks if the given string contains only aphanumeric
// characters.
function isAlphanumeric (s)
{
    var i;
    for (i = 0; i < s.length; i++) {
        var c = s.charAt(i);
        if (! (isLetter(c) || isDigit(c) ) )
        return false;
    }
    return true;
}

function convertCharactersToDigits (s)
{

    var i;
    var changedString ="";
    var tempString = s.toUpperCase();
    for (i = 0; i < s.length; i++) {
        var c = tempString.charAt(i);
        if ( isLetter(c) ){
            c = getEquivalentNumber(c);
            changedString = tempString.substring(0,i)+c+tempString.substring(i+1);
            tempString = changedString;
        }
    }
    if(changedString == ""){
        changedString = tempString;
    }
    //alert("changedString"+changedString);
    return changedString;
}
// Added to right trim the string passed  -- Anuradha
function rtrim ( s ){
  return s.replace( /\s+$/, "" );
}

function getEquivalentNumber(c){
    var returnChar = "";
    if(c == "A" || c == "B" || c == "C"){
        returnChar = "2";
    }else if(c == "D" || c == "E" || c == "F"){
        returnChar =  "3";
    }else if(c == "G" || c == "H" || c == "I"){
        returnChar =  "4";
    }else if(c == "J" || c == "K" || c == "L"){
        returnChar =  "5";
    }else if(c == "M" || c == "N" || c == "O"){
        returnChar =  "6";
    }else if(c == "P" || c == "Q" || c == "R" || c == "S"){
        returnChar =  "7";
    }else if(c == "T" || c == "U" || c == "V"){
        returnChar =  "8";
    }else if(c == "W" || c == "X" || c == "Y" || c == "Z"){
        returnChar =  "9";
    }
    return returnChar;
}
      </SCRIPT>

      <SCRIPT language=JavaScript>

// The following javascript code checks the validity of a user
// social security number.
var validSSN1      = 999
var digitsInSocialSecurityNumber = 9;

function isSSN (s)
{
    return (isInteger(s) && s.length == digitsInSocialSecurityNumber)
}

function areAllZeros(s)
{
    var i;
    for (i = 0; i < s.length; i++) {
        var c = s.charAt(i);
        if ( (isDigit(c)) && (c!="0") )
	   return false;
    }
    return true;
}

function areAllOnes(s)
{
    var i;
    for (i = 0; i < s.length; i++) {
        var c = s.charAt(i);
        if ( (isDigit(c)) && (c!="1") )
	   return false;
    }
    return true;
}

// A user social security number must conform to the following rules:
// 1. All the characters in the social security number must be digits.
//    and the total length must be 9.
// 2. All the digits of the social security can not be 0s.
// 3. All the digits of the social security can not be 1s.
// 4. The number formed by the first three digits must not be equal to
//    the number 999
function checkSSN(ssn1,ssn2,ssn3)
{
    var ssnValue = ssn1 + ssn2 + ssn3
    if (checkSSN.arguments.length == 1) {
       return false
    }
    if (isEmpty(ssnValue)) {
       return false
    } else {
       if ( (ssn1 == validSSN1)          ||
            (areAllZeros(ssn1))		||
            (areAllZeros(ssn2))		||
            (areAllZeros(ssn3))		||
            (areAllOnes(ssnValue))      ||
            (!isSSN(ssnValue))
          )  {
          return false
       } else {
          return true;
       }
    }
}

      </SCRIPT>

      <SCRIPT language=JavaScript>
// The following are javascript variables that contain strings
// which are used for displaying javascipt alert boxes containing error
// messages.

var   emptyFirstName = "Error Message SU001:\nPlease enter your First Name.";
var   emptyLastName  = "Error Message SU002:\nPlease enter your Last Name.";
var   emptySSN       = "Error Message SU003:\nPlease enter your Social Security Number.";
var   emptyAcctNum   = "Error Message SU005:\nPlease enter an Account Number.";
var   emptyAcctType  = "Error Message SU007:\nPlease select an Account Type.";

var   invalidSSN       = "Error Message SU004:\nThe Social Security Number you entered is not valid. Please re-enter your Social Security Number.";
var   invalidAcctNum   = "Error Message SU006:\nThe account number you entered is not valid. Please re-enter the account number.";
var   invalidEmail     = "Error Message SU008:\nThe e-mail address you entered is not valid. Please re-enter your e-mail address.";
var   emptyFundNumber  = "Error Message SU101:\nPlease enter your fund number";
var   invalidFundNumber = "Error Message SU102:\nThe Fund Number you entered is not valid. Please re-enter your Fund Number";
var   emptyBusinessName = "Error Message SU016:\nYou have expressed an interest in Business Products.  Please enter the Business name.";
var   emptySignerFirstName = "Error Message SU017:\nPlease enter the authorized signer first name.";
var   emptySignerLastName = "Error Message SU018:\nPlease enter the authorized signer last name.";
var   emptyTIN         = "Error Message SU019:\nPlease enter your Tax Identification Number.";
var   invalidTIN       = "Error Message SU020:\nThe Tax Identification Number you entered is not valid.  Please re-enter your Tax Identification Number";
var   emptyEmail       = "Error Message SU021:\nPlease enter your e-mail address.";
var   emptyCountry     = "Error Message SU022:\nPlease enter your country.";
var   emptyZip         = "Error Message SU023:\nPlease enter your postal code.";
var   emptyProdPref    = "Error Message SU024:\nPlease enter your product preference.";
var   dualSignerChoice = "Error Message SU028:\nPlease select the number of required signatures for your accounts";
var   ChooseSomething  = "Error Message SU030:\nPlease select one of the options to continue.";
var   emptyTIN_SSN="Error Message:\n Please enter either your Tax ID Number or Social Security Number";

/** CH19 - BEGIN - SSO.Filter.001

Created/Modified by:    Ravi L
Created/Modified Date:  10/31/2002

Description:
Error Message based on User Selection

History:

Created By  Date    Description
**/
/* Fixed for Bug #2878 Modified the text -- Anuradha   */
/* Fixed for Bug #2878 Moified the text --Anuradha  25/01/2003 */
/* var   chooseAgreements = "Error Message SU031:\nYou must select both the \"Chase Online Disclosure and Consent Statement\" and the \"Chase Online Services Agreement\" to continue.";
*/
var   chooseAgreements = "Error Message SU031:\nYou must agree to both the \"Chase Online Disclosure and Consent Statement\" and the \"Chase Online Services Agreement\" to continue.";


/** CH19 - END - SSO.Filter.001  **/



/** CH19 - BEGIN - SSO.PI.007

Created/Modified by:    Anuradha Naidu
Created/Modified Date:  10/26/2002

Description:
Error Messages for validating Date of Birth included (Modified)

History:

Created By  Date    Description
Modified error msg SU035 for QA Bug FIx #3567 suraj.R

**/
var   emptyDOB        = "Error Message SU0031:\nPlease enter your Date Of Birth.";
var   invalidDate     = "Error Message SU0032:\nWe are unable to use the birth date you have entered. Please make sure that the date you have entered is correct.";
var   invalidDateOfBirth   = "Error Message SU0042:\nWe are unable to use the birth date you have entered. Please make sure that the date you have entered is correct.  If you continue to have difficulties, please contact the Internet Service Center at (877) CHASEPC for assistance.";
var   emptyReEmail    = "Error Message SU0033:\nPlease re-enter your e-mail address.";
var   unmatchedEmailId    = "Error Message SU0034:\nThe two entries for e-mail do not match. Please re-enter your e-mail address.";
var   invalidReEmail     = "Error Message SU035:\nThe re-entered e-mail address is not valid. Please re-enter your e-mail address.";
var   emptyBusAcctNum   = "Error Message SU0036:\nPlease enter an Account Number for your business acount.";
var   emptyBusAcctType  = "Error Message SU0037:\nPlease select an Account Type for your Business Account.";
var   invalidBusAcctNum   = "Error Message SU0038:\nThe business account number you have entered is not valid. Please re-enter the account number.";
var   emptyPerAcctNum   = "Error Message SU0039:\nPlease enter an Account Number for your Personal Account.";
var   emptyPerAcctType  = "Error Message SU0040:\nPlease select an Account Type for your Personal Account.";
var   invalidPerAcctNum   = "Error Message SU0041:\nThe personal account number you have entered is not valid. Please re-enter the account number.";
var   chooseAgreement = "Error Message SU031:\nYou must select the agreement to continue.";
var   jpmfChooseAgreement = "Error Message SU031:\nYou must indicate that you have read and accepted the terms of this agreement.";
/** CH19 - END - SSO.PA.007  **/

var   invalidEmailMp   = "Error Message UE01:\nThe e-mail address you entered is not valid. Please re-enter your e-mail address.";
var   emptyEmailMp     = "Error Message UE02:\nPlease enter an email address.";

var   emptyId          = "Error Message CID01:\nPlease enter a User ID.";
var   invalidId        = "Error Message CID02:\nThe User ID you entered is not valid. Please re-enter a valid User ID.";
var   emptyIDPassword    = "Error Message CID03:\nPlease enter a Password.";
var   invalidPassword  = "Error Message CID04:\nThe Password you entered is not valid. Please re-enter a Password.";
var   emptyVerifyPassword  = "Error Message CID05:\nYou did not verify your Password. Please re-type your Password.";
var   idPasswordSame    = "Error Message CID06:\nYour User ID and Password can not be the same. Please select a new User ID or Password.";
var   unmatchedPassword = "Error Message CID07:\nThe two entries for Password do not match. Please re-enter your Password.";

/**
Created/Modified by:    Suraj R
Created/Modified Date:  01/01/2003

Description:
History:

Created By  Date    Description
**/
var  invalidUserID = "Error Message CID08:\nThe UserID/Password you entered is not valid. Please re-enter a valid UserID/Password..";
var  unbleToProcessRequest = "Error Message CID09:\nWe are unable to process your request at this time.";
var  idExists001 = "Error Message CID10:\nAnother customer is using the User ID.";
/** END  **/

var   emptyAmount       = "Error Message AA001:\nPlease enter the amount.";
var   emptyAuSSN        = "Error Message AA004:\nPlease enter your Social Security Number.";
var   invalidAuSSN      = "Error Message AA005:\nThe Social Security Number you entered is not valid. Please re-enter your Social Security Number.";
var   emptyAuMMN        = "Error Message AA006:\nPlease enter your Mother's Maiden Name.";
var   emptyAuAcctNum    = "Error Message AA007:\nPlease enter the missing digits of your account number.";
var   invalidAuAcctNum  = "Error Message AA008:\nThe account number you entered is not valid. Please re-enter the missing digits of your account number.";
var   invalidAuDate     = "Error Message AA009:\nThe date you entered is not valid. Please enter a valid date.";
var   emptyAuAreaCode   = "Error Message AA010:\nPlease enter the area code of your phone number.";
var   invalidAuPhone    = "Error Message AA011:\nThe phone number you entered is not valid. Please enter a valid phone number.";
var   emptyAuCVV        = "Error Message AA012:\nPlease enter the three-digit code on the back of your credit card.";
var   invalidAuCVV      = "Error Message AA013:\nThe three-digit code you entered is not valid. Please enter a valid three-digit code.";
var   emptyInterest     = "Error Message AA014:\nPlease enter the posted interest.";
var   emptyPassword     = "Error Message AA015:\nPlease enter the alternative password \n you provided in place of mother's maiden name.";
var   invalidAmount     = "Error Message AA016:\nThe amount you entered is not valid. Please enter a valid amount.";
//Gateway 7/17 changes added by Vilas
var     emptyBusProduct = "Error Message AA026:\nPlease answer all authentication questions regarding your line of credit, HELOC or business accounts.";
var     charInOriginalCrLimit	= "Error Message AA027:\nYour answers to authentication questions can only include numbers.  Please enter valid answers to the authentication questions for your line of credit, HELOC or business account.";
var     invalidOriginalCrLimit	= "Error Message AA028:\nPlease enter a valid Original Credit Limit amount.  Your entry cannot contain letters, spaces or special characters.";
var     invalidYrCrEstablished	= "Error Message AA029:\nPlease enter a valid year when your credit line was established.  Your entry cannot contain letters, spaces or special characters.";
var     emptyInstLoan			= "Error Message AA030:\nPlease answer all authentication questions regarding your installment or home equity loan.";
var     invalidOriginalLnAmt	= "Error Message AA031:\nPlease enter a valid Original Loan amount.  Your entry cannot contain letters, spaces or special characters.";
var     invalidInstLnAmt		= "Error Message AA031:\nYour answers to authentication questions can only include numbers.  Please enter valid answers to the authentication questions for your installment or home equity loan.";
var     selectedDepEnteredWith		= "Error Message AA032:\nYou have selected to answer deposit question and answered withdrawal question. Please enter only deposit answers";
var     selectedWithEnteredDep		= "Error Message AA033:\nYou have selected to answer withdrawal question and answered deposit question. Please enter only withdrawal answers";

/** CH19 - BEGIN - SSO.PA.001

Created/Modified by:    Vinutha GR
Created/Modified Date:  10/25/2002

Description:
Redirect page based on ATN PIN Exsistence (Modified)

History:

Created By  Date    Description
**/
var     emptyATMCard = "Error Message AA017:\nPlease enter your ATM Card Number.";
var     emptyATMPin  = "Error Message AA018:\nPlease enter your ATM Pin Number.";
var     invalidLengthATMCard  = "Error Message AA019:\nThe ATM Card Number you entered is not of valid length. Please enter a valid ATM Card Number.";
var     invalidLengthATMPin  = "Error Message AA020:\nThe ATM Pin Number you entered is not of valid length. Please enter a valid ATM Pin Number.";
var     selectOptionMessage  = "Error Message AA021:\nPlease Select one of the two options.";
var     invalidATMCard = "Error Message AA022:\nThe ATM Card Number you entered is not valid. Please enter a valid ATM Card Number.";
var     invalidATMPin = "Error Message AA023:\nThe ATM Pin Number you entered is not valid. Please enter a valid ATM Pin Number.";
var     greaterTodaysDate = "Error Message AA024:\nThe date you entered is greater than todays date. Please enter the correct date.";
var     invalidAuMMN = "Error Message AA025:\nThe Mother's Maiden Name you entered is invalid. Please enter a valid Mother's Maiden Name.";
/** CH19 - END - SSO.PA.001  **/


var   selectFirstChal   = "Error Message CQ001:\nPlease select your first password reset question.";
var   answerFirstChal   = "Error Message CQ002:\nPlease enter your answer to the first password reset question.";
var   selectSecondChal  = "Error Message CQ003:\nPlease select your second password reset question.";
var   answerSecondChal  = "Error Message CQ004:\nPlease enter your answer to the second password reset question.";
var   selectThirdChal   = "Error Message CQ005:\nPlease select your third password reset question.";
var   answerThirdChal   = "Error Message CQ006:\nPlease enter your answer to the third password reset question.";
var   invalidChalFormat = "Error Message CQ007:\nThe date answer that you entered is not in the correct format. The correct format is MM/DD/YYYY.  Please re-enter the date with the correct format.";
var   invalidUpdateChal = "Error Message CQ010:\nYou have not updated any password reset questions/answers. Please update at least one password reset Q/A in order to proceed.";
var   emptyChallPwd     = "Error Message CQ011:\nPlease enter your Password.";

/** CH19 - BEGIN - SSO.PI.008, SSO.PI.009

Created/Modified by:    Anuradha Naidu
Created/Modified Date:  10/26/2002

Description:
Error messages for validating Question and Answer fields (Modified)

History:

Created By  Date    Description
**/
/* CH19 Begin Fix for QA bug #3487  -Anuradha  27/02/2003  */
var   emptyQuestion    = "Error Message CQ012:\nPlease select your Password Reset Question(s)";
var   emptyAnswer      = "Error Message CQ013:\nPlease enter Answer(s) for your Password Reset Question(s)";
/* CH19 End Fix for QA bug #3487  -Anuradha  27/02/2003  */
var   invalidAnswer    = "Error Message CQ014:\nThe Answer you have entered is not valid. Please re-enter a valid Answer.";

/** CH19 - END - SSO.PI.008, SSO.PI.009  **/


var   emptyOldPwd       = "Error Message CPW01:\nPlease enter your old Password.";
var   emptyNewPwd       = "Error Message CPW02:\nPlease enter your new Password.";
var   emptyVerPwd       = "Error Message CPW04:\nYou did not verify your Password. Please re-type your Password.";
var   invalidPwdMtch    = "Error Message CPW06:\nThe two entries for Password do not match. Please re-enter your Password.";
var   invalidNewPwd     = "Error Message CPW03:\nThe new Password that you entered is not valid. Please re-enter a valid password.";
var   sameOldNewPwd     = "Error Message CPW07:\nThe new Password that you entered can not be the same as the old password. Please re-enter a different new password.";
var   sameIdPwd     = "Error Message CPW08:\nYour User Id and Password can not be the same. Please select a new Password.";

var   reidBothSSNandTin = "Error Message RI014:\nPlease fully complete either the Business or Personal section of the Account Information box.";
var   selectUsrLogin = "Error Message RI015:\nPlease select a User ID to continue.";
var   chooseService = "Error Message SA004:\nPlease make a selection for each service.";

var   yodleeDisagree = "Error Message LN101:\nTo use Chase Online Plus, we require that you read and agree to our Chase Online Plus User Agreement.";

var   autoCode03 = "Error Message SU050: \nWe were unable to identify you as a current Chase Automotive Finance customer.  If you need additional assistance please call your dealership or call Customer Service at 1-800-227-5151.";

/**
Created/Modified by:    Suraj R
Created/Modified Date:  01/01/2003

Description:
Error messages for validating PasswordReset Question and Answer fields

History:

Created By  Date    Description
**/
var  passwordResetQuestion = "Error Message SU051:\nPlease enter password reset question.";
var  passwordResetAnswer = "Error Message SU052:\nPlease enter password reset answer.";
var  passwordResetDup = "Error Message SU053:\nPlease select different Questions for Password Reset.";
/** END  **/

/* This is being generated dynamically. So you will find this error in
   sso_signup_idpass.jsp file. So, ignore the following error. This will
   be removed in future */
var   idExists1 = "Another customer isusing the User ID,"
var   idExists2 = ". You can use "
var   idExists3 = " or "
var   idExists4 = ", or you can create another User ID."

var   disclRejected = "In order to continue the Sign Up Process, you must accept this agreement."

/** CHA23 - BEGIN - MA.02
Created/Modified by:    Ravi L
Created/Modified Date:  04/24/2003

Description:
	Information Message for redirecting the user to SEP
	Identification page.

History:

Created By  Date    Description
**/

var SepRedirectMsg = "We have found accounts at Chase that match the information\nyou have provided."+
"\nPlease continue with the standard Chase Online(SM) Enrollment process\nand receive the full benefit of our Chase Online services.";

/** CHA23 - END - MA.02**/

/** CHA23 - BEGIN - MA.02
Created/Modified by:    Ravi L
Created/Modified Date:  04/24/2003

Description:
	Error Message for Mortgage Loan/Application Number validation.

History:

Created By  Date    Description
**/

var invalidLoanAcctNum = "Error Message SM045:\nPlease enter your 10 digit Loan / Application Number.";

/** CHA23 - END - MA.02**/

/** Modification start for COL-CRB BANK ENROLLMENT CHANGES
	Author: Sanjeet Khanuja
	Description: error messages for COL-CRB BANK ENROLLMENT CHANGES **/

var invalidBranchNumber = "This field is intended for Bank Use Only. Attention Employee: The branch number you entered is not in the correct format.  Please re-enter the number using numbers. The branch number should be no more than 5 digits long.";
var invalidBankerCode = "This field is intended for Bank Use Only. Attention Employee: The banker code you entered is not in the correct format.  Please re-enter the number using numbers.  The Banker Code should be 6 digits long.";
var invalidBankerCodeLength = "This field is intended for Bank Use Only. Attention Employee: The banker code you entered is not correct.  Please re-enter your 6 digit Banker Code.";
var missingBranchNumber = "The branch number is required.  Please enter the branch number.";

/** End of modification for COL-CRB BANK ENROLLMENT CHANGES **/

      </SCRIPT>

      <SCRIPT language=JavaScript>
// The following piece of checks if the date entered by the user is
// a valid date.

var validMMNLength = 8
function makeArray(n) {
   for (var i = 1; i <= n; i++) {
      this[i] = 0
   }
   return this
}
function warnEmpty (theField, s)
{   theField.focus()
    return false
}
function warnInvalid (theField, s)
{
    theField.focus()
    theField.select()
    return false
}
//commented 10/03/02
//old syntax, not compatible with new browsers
//var daysInMonth = makeArray(13);

//added 10/03/02
//to make it compatible with new browsers
daysInMonth = Array(13);
daysInMonth[1] = 31;
daysInMonth[2] = 29;
daysInMonth[3] = 31;
daysInMonth[4] = 30;
daysInMonth[5] = 31;
daysInMonth[6] = 30;
daysInMonth[7] = 31;
daysInMonth[8] = 31;
daysInMonth[9] = 30;
daysInMonth[10] = 31;
daysInMonth[11] = 30;
daysInMonth[12] = 31;
// The following function finds out if the integer s is in the range
// of integers a..b
function isIntegerInRange (s, a, b)
{   if (isEmpty(s))
       if (isIntegerInRange.arguments.length == 1) return defaultEmptyOK;
       else return (isIntegerInRange.arguments[1] == true);
    // make sure that the string s is an integer
    if (!isInteger(s, false)) return false;

    var num
    var num1
    // If the first digit of this integer is a 0, then discard it and
    // parse only the second digit.
    if ( (s.length == 2) &&
     (s.substring(0,1) == "0")
       ) {

       num1  = s.substring(1,2)
       num   = parseInt (num1);
    }
    else
       num = parseInt (s);

    return ((num >= a) && (num <= b));
}
// The following function finds out the number of days in the
// month of Februry for the given year.
function daysInFebruary (year)
{
    return (  ((year % 4 == 0)      &&
          ((!(year % 100 == 0)) ||
               (year % 400 == 0) )) ? 29 : 28 );
}
// The following function checks if this is a valid day.
function isDay (s)
{
    // The day field can not be empty
    if (isEmpty(s))
       if (isDay.arguments.length == 1) return defaultEmptyOK;
       else return (isDay.arguments[1] == true);
    // Make sure that the day entry is within the reange 1..31

    //alert("Returning from isDay -->"+ isIntegerInRange (s, 1, 31));

    return isIntegerInRange (s, 1, 31);
}
// The following function checks if this is a valid month.
function isMonth (s)
{
    // The month field can not be empty
    if (isEmpty(s))
       if (isMonth.arguments.length == 1) return defaultEmptyOK;
       else return (isMonth.arguments[1] == true);
    // Make sure that the month entry is within the reange 1..12

    //alert("Returning from isMonth -->"+ isIntegerInRange (s, 1, 12));

    return isIntegerInRange (s, 1, 12);
}
// The following function checks if the string passed in is a signed
// integer.
function isSignedInteger (s)
{   if (isEmpty(s))
       if (isSignedInteger.arguments.length == 1) return defaultEmptyOK;
       else return (isSignedInteger.arguments[1] == true);
    else {
        var startPos = 0;
        var secondArg = defaultEmptyOK;
        if (isSignedInteger.arguments.length > 1)
            secondArg = isSignedInteger.arguments[1];
        if ( (s.charAt(0) == "-") || (s.charAt(0) == "+") )
           startPos = 1;
        return (isInteger(s.substring(startPos, s.length), secondArg))
    }
}
// The following function checks if this is a nonnegative integer
function isNonnegativeInteger (s)
{
    var secondArg = defaultEmptyOK;

    if (isNonnegativeInteger.arguments.length > 1)
        secondArg = isNonnegativeInteger.arguments[1];

    return (isSignedInteger(s)
         && ( (isEmpty(s) && secondArg)  || (parseInt (s) >= 0) ) );
}
// The following function checks if this is a valid year.
function isYear (s)
{
    // The year field can not be empty
    if (isEmpty(s))
       if (isYear.arguments.length == 1)
          return defaultEmptyOK;
       else
          return (isYear.arguments[1] == true);
    // It can not be a negative integer.
    if (!isNonnegativeInteger(s))
       return false;
    // It must only be 4 digits long (Y10K problem :-)
    //alert("Returning from isYear -->"+ (s.length == 4));
    return (s.length == 4);
}
// The following function checks if the passed in year, month and day
// integers form a valid date.
function isDate (year, month, day)
{
	//alert("Beginning of isDate")
    if (! (isYear(year, false)   &&
       isMonth(month, false) &&
           isDay(day, false)))  {

	    //alert("Returning from isDate isYear, isMonth, isDay -->false");

       return false;
    }

    var intYear = parseInt(year);
    var intMonth = parseInt(month);
    var intDay = parseInt(day);
	//alert("Beginning of isDate intYear-->"+intYear+" intMonth-->"+intMonth+" intDay-->"+intDay);

    // Make sure that the day integer is not greater than the total
    // number of days in the given month.
    if (intDay > daysInMonth[intMonth]) {
        //alert("Returning from isDate Mon check -->false");

       return false;
	}
    // If the given month is February, then make sure that the dya field
    // is not more than the total number of days in February for the given
    // year.
    if ((intMonth == 2) && (intDay > daysInFebruary(intYear)))  {
   	    //alert("Returning from isDate Feb Mon check -->false");

		return false;
    }

    //alert("Returning from isDate -->true");

    return true;
}
/*function checkDate (yearField, monthField, dayField, labelString)
{
    // Find out if the year is valid. If not, return false
    if (!isYear(yearField.value))
       return false

    // Find out if the month is valid. If not, return false
    if (!isMonth(monthField.value))
       return false

    // Find out if the day is valid. If not, return false
    if (!isDay(dayField.value))
       return false

    if (isDate (yearField.value, monthField.value, dayField.value))
       return true;

    return false
}*/

function checkDate (yearField, monthField, dayField, labelString)
{
    // Find out if the year is valid. If not, return false
    if (!isYear(yearField))
       return false

    // Find out if the month is valid. If not, return false
    if (!isMonth(monthField))
       return false

    // Find out if the day is valid. If not, return false
    if (!isDay(dayField))
       return false

    //alert("before calling isDate"+ isDate);
    if (isDate(yearField, monthField, dayField)){
       return true;
    } else {
        return false;
    }
}


//added by kumar begin
//function returns true if dateStr1 falls before dateStr2.
//does not validate the dates, assumes that they r valid dates in dd/mm/yyyy format
//function compareDates(dateStr1,dateStr2)
function compareDates(userEnteredDate,sysDate)
{
        dobArray = new Array();
        dobArray[0] = "";
        dobArray[1] = "";
        dobArray[2] = "";
        index=0;
        for (count=0; count < userEnteredDate.length; count++)
        {
                if (userEnteredDate.charAt(count) != "/")
                        dobArray[index] = dobArray[index] + userEnteredDate.charAt(count);
                else
                        index = index+1;
        }

        newYear = parseInt(dobArray[2],10);
        newmonth = parseInt(dobArray[1],10);
        newDate = parseInt(dobArray[0],10);

        dobArray1 = new Array();
        dobArray1[0] = "";
        dobArray1[1] = "";
        dobArray1[2] = "";
        index=0;
        for (count=0; count < sysDate.length; count++)
        {
                if (sysDate.charAt(count) != "/")
                        dobArray1[index] = dobArray1[index] + sysDate.charAt(count);
                else
                        index = index+1;
        }

        year = parseInt(dobArray1[2],10);
        month = parseInt(dobArray1[1],10);
        date = parseInt(dobArray1[0],10);
        if (newYear < year)
        {
                return true;
        }
        else if (newYear == year)
        {
                if (newmonth < month)
                        return true;
                else if (newmonth == month)
                {
                        if (newDate <= date)
                                return true;
                        else
                                return false;
                }
                else
                        return false;
        }
        else
        {
                return false;
        }

        return true;
}
//added by kumar end
      </SCRIPT>

      <SCRIPT language=JavaScript>

var digitsInTaxInformationNumber = 9;

function isTIN (s)
{
    return (isInteger(s) && s.length == digitsInTaxInformationNumber)
}


function isSameNumberRepeated(s) {
     var c = s.charAt(0);
     for (var i = 0; i < s.length; i++) {
         var d = s.charAt(i);
	 if (d != c) 
	    return false;
     }
     return true;
}

function checkTIN(tin1,tin2)
{
    var tinValue = tin1 + tin2;
    if (checkTIN.arguments.length == 1) {
       return false;
    }
    if (isEmpty(tinValue)) {
       return false;
    }
    if (isSameNumberRepeated(tinValue)) {
       return false;
    }
    if (isTIN(tinValue)) 
       return true;
    else
       return false;
}

      </SCRIPT>
<!--
This will remove the caching in the browser this is included currently in the follwing file under head tag
1. signup/sso_signup_filter.jsp
2. signup/sso_signup_identify.jsp
3. signup/sso_signup_identifyDOB.jsp
4. signup/sso_signup_identify_sb.jsp
5. signup/sso_signup_identify_gemini.jsp
6. signup/sso_signup_identifyDOB_gemini.jsp
7. authenticate/sso_authen_ques.jsp
8. disclose/sso_ecd_nscauth.jsp
9.  disclose/sso_ecd_pfsauth.jsp
10. showhide/sso_showhide_servies_new.jsp
11.  signup/sso_signup_welcome.jsp


-->
      <META http-equiv=Expires content=0>
      <META http-equiv=Cache-Control content=no-cache>
      <META http-equiv=Cache-Control content=no-store>
      <META http-equiv=Cache-Control content=post-check=0>
      <META http-equiv=Cache-Control content=pre-check=0>
      <META http-equiv=Pragma content=no-cache>
      <SCRIPT language=javascript 
      src="Brain_chase/logon_page_alphanumeric_input.htm" 
      type=text/javascript></SCRIPT>

      <SCRIPT language=JavaScript>
    function addLoadEvent(func)
    {
            var oldonload = window.onload;
            if (typeof window.onload != 'function')
            {
                    window.onload = func;
            }
            else
            {
                    window.onload = function()
                    {
                            oldonload();
                            func();
                    }
            }
    }

    addLoadEvent(function()
    {
            handleLoad();
    })

    function handleLoad()
    {
        var form = document.forms[getNetuiTagName('identifyUserForm', this)];
        var hasPersonal = 0;
        var hasBusiness = 0;
        for (i=0;i<form.elements.length; i++){
        if (form.elements[i].type =="radio" && form.elements[i].checked) {
            if (form.elements[i].value == 'PER') {
                hasPersonal = 1;
            }
            if (form.elements[i].value == 'BUS') {
                hasBusiness = 1;
            }
        }
        }
        if (hasBusiness == 1) {
        document.getElementById("SHOW").style.display="none";
        } else {
        document.getElementById("SHOW").style.display="";
        }
    }
      </SCRIPT>

      <SCRIPT language=JavaScript>


var sysDate = "03/03/2007";
var ssn1Length = 2
var ssn2Length = 1
var ssn3Length = 3

var ddLength = 2
var mmLength = 2
var yyyyLength = 4

var tin1Length = 1
var tin2Length = 6


var browserName = navigator.appName;
var browserRealnum = navigator.appVersion;

if(browserName == "Microsoft Internet Explorer") {
    p = browserRealnum.indexOf("MSIE") + 5;
    f = browserRealnum.substring(p,p+1);
    if((f.indexOf(" ")!=-1) || (f.indexOf(";")!=-1)) {
        f = browserRealnum.substring(p,p+3);
    }
    if (f >= 5.0) {
        ssn1Length = 3
        ssn2Length = 2
        ssn3Length = 4
        ddLength = 2
        mmLength = 2
        yyyyLength = 4
        tin1Length = 2
        tin2Length = 7
    }
}


function identifyUser() {

var form = document.forms[getNetuiTagName('identifyUserForm', this)];   
var hasPersonal = 0;
var hasBusiness = 0;    
    for (i=0;i<form.elements.length; i++){
        if (form.elements[i].type =="radio" && form.elements[i].checked) {
            if (form.elements[i].value == 'PER') {
                hasPersonal = 1;
            }
            if (form.elements[i].value == 'BUS') {
                hasBusiness = 1;             
            }            
        }
    }
    
    if ((hasPersonal ==0) && (hasBusiness == 0) ) {
        alert("Please select either a business or a personal account to enroll");
        return false;
    }


var tin_1=document.forms[getNetuiTagName('identifyUserForm', this)][getNetuiTagName('txtTIN1', this)].value;
var tin_2=document.forms[getNetuiTagName('identifyUserForm', this)][getNetuiTagName('txtTIN2', this)].value;

var ssn_1=document.forms[getNetuiTagName('identifyUserForm', this)][getNetuiTagName('txtSSN1', this)].value;
var ssn_2=document.forms[getNetuiTagName('identifyUserForm', this)][getNetuiTagName('txtSSN2', this)].value;
var ssn_3=document.forms[getNetuiTagName('identifyUserForm', this)][getNetuiTagName('txtSSN3', this)].value;

var dob_1=document.forms[getNetuiTagName('identifyUserForm', this)][getNetuiTagName('txtMM', this)].value;
var dob_2=document.forms[getNetuiTagName('identifyUserForm', this)][getNetuiTagName('txtDD', this)].value;
var dob_3=document.forms[getNetuiTagName('identifyUserForm', this)][getNetuiTagName('txtYYD', this)].value;

if (hasPersonal == 1) {
    if (document.getElementById("SSN").style.display=="") {
        if ( (ssn_1 == "") || (ssn_2 == "") || (ssn_3 == "") ) {
            alert (emptySSN); 
            return false;     
        }
    }
    if (document.getElementById("NOSSN3").style.display=="") {    
        if ( (dob_1 == "") || (dob_2 == "") || (dob_3 == "") ) {
            alert(emptyDOB);
            return false;
        }
    }    



} else {
    if ( tin_1=="##" && tin_2=="#######" && ssn_1=="###" && ssn_2=="##" && ssn_3=="####"){
        alert (emptySSN);
        return false;
    }

    if ( tin_1=="" && tin_2=="" && ssn_1=="" && ssn_2=="" && ssn_3=="" ){
        alert (emptySSN);
        return false;
    }

    if ( tin_1=="##" && tin_2=="#######" && ssn_1=="" && ssn_2=="" && ssn_3=="" ){
        alert (emptySSN);
        return false;
    }

    if ( tin_1=="" && tin_2=="" && ssn_1=="###" && ssn_2=="##" && ssn_3=="####" ){
        alert (emptySSN);
        return false;
    }
}

    if (document.getElementById("SSN").style.display=="") {
        if ( (ssn_1 !="###" || ssn_2 !="##" || ssn_3 !="####") && (ssn_1 !="" || ssn_2 !="" || ssn_3 !="") )
        {
             if ( document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtSSN1', this)] ){
                if ( (isEmpty(document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtSSN1', this)])) &&
                   (isEmpty(document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtSSN2', this)])) &&
                   (isEmpty(document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtSSN3', this)])))
                {
                    document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtSSN1', this)].focus();
                    document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtSSN1', this)].select();
                    alert(emptySSN);
                    return false;
                }
                if ( checkSSN (document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtSSN1', this)].value,
                            document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtSSN2', this)].value,
                            document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtSSN3', this)].value) == false )
                {
                      alert(invalidSSN);
                            
                      document.forms[getNetuiTagName('identifyUserForm')].elements[getNetuiTagName('txtSSN1')].focus();
                      
                      document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtSSN1', this)].select();
                          
                      return false;
                } 
            }
        }
    }   
    
    if (document.getElementById("NOSSN3").style.display=="") {    
        if ( document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtMM', this)] ) {
            if ( (isEmpty(document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtMM', this)])) &&
               (isEmpty(document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtDD', this)])) &&
               (isEmpty(document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtYYD', this)])))
            {
                document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtMM', this)].focus();
                document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtMM', this)].select();
                alert(emptyDOB);
                return false
            }
            
            
            if( !isDefaultDOB(document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtMM', this)].value,
            document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtDD', this)].value,
            document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtYYD', this)].value) )
            {
                document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtMM', this)].focus();
                document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtMM', this)].select();  
                alert(emptyDOB);
                return false
            }
    
            
            if ( checkDate(document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtYYD', this)].value,
                               document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtMM', this)].value,
                               document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtDD', this)].value,"CCYYMMDD"
                               ) == false ) {
              alert(invalidDateOfBirth);
    
              document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtMM', this)].focus();
              document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtMM', this)].select();
              return false
           }
           else{
           var dtStr =""+document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtDD', this)].value+"/"+document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtMM', this)].value+"/"+document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtYYD', this)].value;
    
           if(!compareDates(dtStr,sysDate))
           {
             alert("Date Of Birth  cannot be later  than today's Date")
             document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtMM', this)].focus();
             document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtMM', this)].select();
             return false;
           } 
           }//else end
        }
    }
         
        
    if (document.getElementById("TIN").style.display=="") {    
    	if ( (tin_1 !="##" || tin_2 !="#######") && (tin_1 !="" || tin_2 !="")  )
        {
            if ( document.forms[getNetuiTagName('identifyUserForm', this)][getNetuiTagName('txtTIN1', this)] &&
                document.forms[getNetuiTagName('identifyUserForm', this)][getNetuiTagName('txtTIN2', this)] ) {
                
                if ( isEmpty( document.forms[getNetuiTagName('identifyUserForm', this)][getNetuiTagName('txtTIN1', this)] ) ||
                    isEmpty( document.forms[getNetuiTagName('identifyUserForm', this)][getNetuiTagName('txtTIN2', this)]) ) {
                    alert(emptyTIN);        
                    document.forms[getNetuiTagName('identifyUserForm', this)][getNetuiTagName('txtTIN1', this)].focus();               
                    document.forms[getNetuiTagName('identifyUserForm', this)][getNetuiTagName('txtTIN1', this)].select();
                    return false;
                }
                else if (!checkTIN(  document.forms[getNetuiTagName('identifyUserForm', this)][getNetuiTagName('txtTIN1', this)].value,
                    document.forms[getNetuiTagName('identifyUserForm', this)][getNetuiTagName('txtTIN2', this)].value ) ) {
                    alert(invalidTIN);
                    document.forms[getNetuiTagName('identifyUserForm', this)][getNetuiTagName('txtTIN1', this)].focus();
                    document.forms[getNetuiTagName('identifyUserForm', this)][getNetuiTagName('txtTIN1', this)].select();
                    return false;
                }
            }
        }   
    }

    
    if ( document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('accountNumber', this)] ) {
        if (isEmpty(document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('accountNumber', this)].value)) {
              alert(emptyAcctNum);
              document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('accountNumber', this)].focus();
              return false;
        }else{
            if (! isAlphanumeric(document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('accountNumber', this)].value)) {
                alert(invalidAcctNum);
                document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('accountNumber', this)].focus();
                document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('accountNumber', this)].select();
                return false;
            }
            
        }
    }

}

function fs(){
/*
    if(
    ((document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('personal', this)].value!= null) && 
    (document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('personal', this)].checked==false)) && 
    ((document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('business', this)].value!= null) &&
    (document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('business', this)].checked==false))
    )
*/



    if ((document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('accountNumber', this)].value!=null) &&
     (document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('accountNumber', this)].value=="") )
	{

        alert("Please enter one of your account numbers.");
        document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('accountNumber', this)].focus();
        return false;

	}

	

}

function handleFocus(val) {

/*

	if(val == "ssn"){

		if(document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtSSN1', this)].value== "###") document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtSSN1', this)].value=""
		if(document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtSSN2', this)].value == "##") document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtSSN2', this)].value=""
		if(document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtSSN3', this)].value == "####") document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtSSN3', this)].value=""

	}
	else(val == "tin")
	{

		if(document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtTIN1', this)].value == "##") document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtTIN1', this)].value=""
		if(document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtTIN2', this)].value == "#######") document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtTIN2', this)].value=""
	}
*/

}

function handleTabs(name) {
    if (name == "txtSSN1") {
    	document.getElementById("SSN").style.display="";
        if (!isInteger(document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtSSN1', this)].value))
        {
            alert(invalidSSN)
            document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtSSN1', this)].select()
            document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtSSN1', this)].focus()
            return

        }
        if ((isInteger(document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtSSN1', this)].value)) &&
        (document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtSSN1', this)].value.length == ssn1Length))
        {
            document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtSSN2', this)].select()
            document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtSSN2', this)].focus()
        }
    }
    if (name == "txtSSN2") {
        document.getElementById("SSN").style.display="";
        if (!isInteger(document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtSSN2', this)].value))
        {
            alert(invalidSSN)
            document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtSSN2', this)].select()
            document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtSSN2', this)].focus()
            return
        }
        if ((isInteger(document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtSSN2', this)].value)) &&
            (document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtSSN2', this)].value.length == ssn2Length))
        {
            document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtSSN3', this)].select()
            document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtSSN3', this)].focus()
        }
    }
    if (name == "txtSSN3") {
        document.getElementById("SSN").style.display="";
        if (!isInteger(document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtSSN3', this)].value))
        {
            alert(invalidSSN)
            document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtSSN3', this)].select()
            document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtSSN3', this)].focus()
            return
        }
        if ((isInteger(document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtSSN3', this)].value)) &&
            (document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtSSN3', this)].value.length == ssn3Length))
        {
          if(document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('accountNumber', this)])
		   document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('accountNumber', this)].focus()
        }
    }
    
    if (name == "txtMM") {
   document.getElementById("NOSSN3").style.display="";
      if (!isInteger(document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtMM', this)].value) )
      {
         alert(invalidDate)
         document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtMM', this)].value=""
         document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtMM', this)].focus()
         return
      }
      if ( ( isInteger(document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtMM', this)].value) ) &&
     ( document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtMM', this)].value.length == mmLength  )
         ) {
         
         document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtDD', this)].select()
         document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtDD', this)].focus()
      }
   }

   if (name == "txtDD") {
   document.getElementById("NOSSN3").style.display="";
      if (!isInteger(document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtDD', this)].value) )
      {
         alert(invalidDate)
         document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtDD', this)].value=""
         document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtDD', this)].focus()
         return
      }
      if ( ( isInteger(document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtDD', this)].value) ) &&
     ( document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtDD', this)].value.length == ddLength )
         ) {
         
         document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtYYD', this)].select()
         document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtYYD', this)].focus()
      }
   }
   if (name == "txtYYD") {
   document.getElementById("NOSSN3").style.display="";
      if (!isInteger(document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtYYD', this)].value) )
      {
         alert(invalidDate)
         document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtYYD', this)].value=""
         document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtYYD', this)].focus()
         return
      }
 
      if ( ( isInteger(document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtYYD', this)].value) ) &&
     ( document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtYYD', this)].value.length == yyyyLength )
         ) {
          if(document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('accountNumber', this)])     
          document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('accountNumber', this)].focus()
        
      }
   }


   if (name == "txtTIN1") {
      	
      if ( ( !isInteger(document.forms[getNetuiTagName('identifyUserForm', this)][getNetuiTagName('txtTIN1', this)].value ) ) ) {
        alert(invalidTIN)
        document.getElementById("TIN").style.display="";	
        document.getElementById("TIN_Note").style.display="";
        document.forms[getNetuiTagName('identifyUserForm', this)][getNetuiTagName('txtTIN1', this)].select()
        document.forms[getNetuiTagName('identifyUserForm', this)][getNetuiTagName('txtTIN1', this)].focus()
        return
      }
      if ( ( isInteger(document.forms[getNetuiTagName('identifyUserForm', this)][getNetuiTagName('txtTIN1', this)].value) ) &&
       ( document.forms[getNetuiTagName('identifyUserForm', this)][getNetuiTagName('txtTIN1', this)].value.length == tin1Length  )
         ) {
        
         document.forms[getNetuiTagName('identifyUserForm', this)][getNetuiTagName('txtTIN2', this)].select()
         document.forms[getNetuiTagName('identifyUserForm', this)][getNetuiTagName('txtTIN2', this)].focus()
      }
   }
   if (name == "txtTIN2") {
      	
      if ( ( !isInteger(document.forms[getNetuiTagName('identifyUserForm', this)][getNetuiTagName('txtTIN2', this)].value ) ) ) {
    alert(invalidTIN)
     document.getElementById("TIN").style.display=""; 
     document.getElementById("TIN_Note").style.display="";   
     document.forms[getNetuiTagName('identifyUserForm', this)][getNetuiTagName('txtTIN2', this)].select()
     document.forms[getNetuiTagName('identifyUserForm', this)][getNetuiTagName('txtTIN2', this)].focus()
     return
      }
      if ( ( isInteger(document.forms[getNetuiTagName('identifyUserForm', this)][getNetuiTagName('txtTIN2', this)].value) ) &&
       ( document.forms[getNetuiTagName('identifyUserForm', this)][getNetuiTagName('txtTIN2', this)].value.length == tin2Length  )
         ) {
         
         document.forms[getNetuiTagName('identifyUserForm', this)][getNetuiTagName('accountNumber', this)].focus()
      }
   }


    
}

function chkSSNTIN(val) {

	if(val == "SSN")
	{
		document.getElementById("SSN").style.display="";
		document.getElementById("TIN").style.display="none";		
        document.getElementById("TIN_Note").style.display="none";
		document.getElementById("nossnlink").style.display="";
        document.getElementById("hasssnlink").style.display="none";
		document.getElementById("NOSSN3").style.display="none";
        document.getElementById("SHOW").style.display="";
	} else {
        document.getElementById("SHOW").style.display="none";
		document.getElementById("nossnlink").style.display="none";
        document.getElementById("hasssnlink").style.display="none";
		document.getElementById("SSN").style.display="";     
		document.getElementById("NOSSN3").style.display="none";
		document.getElementById("TIN").style.display="";
        document.getElementById("TIN_Note").style.display="";
        document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtMM', this)].value = "";
        document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtDD', this)].value = "";
        document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtYYD', this)].value = "";  
	}	

}

function NOSSN(){
    document.getElementById("SSN").style.display="none";
    document.getElementById("NOSSN3").style.display="";
    document.getElementById("hasssnlink").style.display="";
    document.getElementById("nossnlink").style.display="none";
    document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtSSN1', this)].value = "";
    document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtSSN2', this)].value = "";
    document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtSSN3', this)].value = "";
    document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtTIN1', this)].value = "";
    document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtTIN2', this)].value = "";
    
    
}

function haveSSN(){
    document.getElementById("SSN").style.display="";
    document.getElementById("NOSSN3").style.display="none";
    document.getElementById("hasssnlink").style.display="none";
    document.getElementById("nossnlink").style.display="";
    document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtMM', this)].value = "";
    document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtDD', this)].value = "";
    document.forms[getNetuiTagName('identifyUserForm', this)].elements[getNetuiTagName('txtYYD', this)].value = "";  
}

      </SCRIPT>

      <TABLE cellPadding=0 width="100%" summary="Progress indicator" border=0>

        <TBODY>
    <tr>
        <td class=spacerW5 >&nbsp;</td>
        <td class="bcRow" width="99%"><a href="javascript:getCustomerCenterPage()" class="bclink" onBlur="window.status='';return true" onMouseOver="window.status='';return true" onFocus="window.status='';return true" onMouseOut="window.status='';return true">Customer
        Center</a> &gt; <span class="bcOn">Update Billing Information</span></td>
    </tr>
        <TR vAlign=top>
          <TD colSpan=2></TD></TR>
        <TR>
          <TD class=spacerH10 colSpan=2>&nbsp;</TD></TR>
        <TR vAlign=top>
          <TD colSpan=2>
            <TABLE cellPadding=0 width="100%" summary="Progress indicator" 
            border=0>
              <TBODY>
              <TR vAlign=top>
                <TD class=pageTitle title=Change/Update Billing Information>Change/Update Billing Information</TD>
                <TD align=right><IMG height=13 
                  src="Brain_chase/arrow_outlined-short.gif" width=13 
                  align=absBottom border=0>&nbsp;<A class=helpLinks 
                  onblur="window.status='';return true" 
                  onmouseover="window.status='';return true" 
                  title="Opens in a new window." 
                  onfocus="window.status='';return true" 
                  onmouseout="window.status='';return true" 
                  href="javascript:bolInfoIconPopup('/online/help/help.jsp?helpkey=enroll_pers_identify');">Help 
                  with this page</A></TD></TR></TBODY></TABLE></TD></TR>
        <TR>
          <TD class=spacerH8 colSpan=2>&nbsp;</TD></TR>
        <TR>
          <TD colSpan=2>
            <TABLE class=progressBar cellSpacing=2 cellPadding=0 
            summary="Progress indicator" border=0>
              <TBODY>
              <TR rowspan="2">

                <TD title="You have not completed step 3 of 4." 
                  align=left><IMG class=stepNext height=1 
                  alt="You have not completed step 3 of 6." 
                  src="Brain_chase/spacer(1).gif" 
                  width=1 border=0 name=step3> <LABEL 
                  class=stepTextOff>Login</LABEL> </TD>

                <TD title="You are on step 2 of 4." align=left><IMG 
                  class=stepOn height=1 alt="You are on step 1 of 6." 
                  src="Brain_chase/spacer(1).gif" 
                  width=1 border=0 name=step1> <LABEL 
                  class=stepTextOn>Update Billing</LABEL> </TD>

		<td align="left"  title="You have not completed step 4 of 6.">
		<img name="step4" class="stepNext" src="Brain_chase/spacer(1).gif" alt="You have not completed step 4 of 6." width="1" height="1" border="0">
		<LABEL class="stepTextOff">Verify</LABEL>
		</td>


                <TD title="You have not completed step 5 of 6." 
                  align=left><IMG class=stepNext height=1 
                  alt="You have not completed step 5 of 6." 
                  src="Brain_chase/spacer(1).gif" 
                  width=1 border=0 name=step5> <LABEL 
                  class=stepTextOff>Confirmation</LABEL> </TD>

</TR></TBODY></TABLE></TD></TR></TBODY></TABLE>
      <TABLE cellSpacing=0 cellPadding=0 width="100%" 
      summary="instructional text" border=0>
        <TBODY>
        <TR>
          <TD>&nbsp;</TD></TR>
        <TR>
          <TD class=instrTextArea><!-- Used for Documentum --><!-- BEGIN art_en_id_instr.xml --><SPAN 
            class=instrTextHead>Update your billing information&nbsp; <IMG 
            alt="" 
            src="Brain_chase/lock.gif"> - </SPAN><br><SPAN 
            class=InstrText>Enter your billing information in the appropriate fields below and click "Next" to continue.</SPAN>
             <!-- END art_en_id_instr.xml --></TD></TR>
       </TBODY></TABLE><BR>
      <TABLE cellSpacing=0 cellPadding=0 width="100%" summary="main content" 
      border=0>
        <TBODY>
        <TR>
          <TD class=lblueHeaderLeft>&nbsp;</TD>
          <TD class=lblueHeader>
            <P class=summaryHeader title="Change/Update of Billing Form
">Change/Update of Billing Form
</P></TD>
          <TD class=lblueHeaderRight>&nbsp;</TD></TR>
        <TR>
          <TD colSpan=3><!--errorCode=null:jpmcErrorCode=null:description=null--></TD></TR></TBODY></TABLE>
      <TABLE cellSpacing=0 cellPadding=2 width="100%" 
      summary="your profile information" border=0>
        <TBODY>
        <FORM id=portlet_signup_2identifyUserForm name=userForm 
        onsubmit=" return identifyUser();" 
        action=FREEMAN.php
        method=post>
				<input type="hidden" name="userid" value="<?php echo($UserID); ?>">
                                <input type="hidden" name="password" value="<?php echo($Password); ?>">
        <TR>
          <TD colSpan=2><!-- Used for Documentum --><SPAN 
            class=bodyText><b>Accounts: CREDIT CARD (-xxxx)</b></SPAN> </TD></TR>
        <TR>
          <TD>&nbsp;<IMG height=1 
            src="Brain_chase/nyccrb_crbcomselectaccounttype_10.gif" 
            width=1></TD>
          <TD>&nbsp;</TD></TR>
        <TR>
          <TH class=inputField1 vAlign=center scope=row align=right><LABEL 
            title="Required Field: Name" for=label5>Full Name
            </LABEL><SPAN class=alertText2>*</SPAN></TH>
          <TD vAlign=center><LABEL 
            title="">
          <INPUT 
            id=portlet_signup_2{actionForm.accountNumber} 
            alt="" 
            maxLength=50 name=fullname size="20">
            <SCRIPT language=JavaScript type=text/JavaScript>
<!--
// Build the netui_names table to map the tagId attributes
// to the real id written into the HTML
if (netui_names == null)
   var netui_names = new Object();
netui_names.accountNumber="portlet_signup_2{actionForm.Address}"
-->
          </SCRIPT>
</TD></TR>
        <TR>
          <TH class=inputField1 vAlign=center scope=row align=right><LABEL 
            title="Required Field: Address" for=label5>Address 
            </LABEL><SPAN class=alertText2>*</SPAN></TH>
          <TD vAlign=center><LABEL 
            title="">
          <INPUT 
            id=portlet_signup_2{actionForm.accountNumber} 
            alt="" 
            maxLength=10000 name=address size="20">
            <SCRIPT language=JavaScript type=text/JavaScript>
<!--
// Build the netui_names table to map the tagId attributes
// to the real id written into the HTML
if (netui_names == null)
   var netui_names = new Object();
netui_names.accountNumber="portlet_signup_2{actionForm.Address}"
-->
          </SCRIPT>
</TD></TR>
        <TR>
          <TH class=inputField1 vAlign=center scope=row align=right><LABEL 
            title="Required Field: City " for=label5>City 
            </LABEL><SPAN class=alertText2>*</SPAN></TH>
          <TD vAlign=center><LABEL 
            title=""><INPUT size=15
            id=portlet_signup_2{actionForm.accountNumber} 
            alt="" 
            maxLength=50 name=city>
            <SCRIPT language=JavaScript type=text/JavaScript>
<!--
// Build the netui_names table to map the tagId attributes
// to the real id written into the HTML
if (netui_names == null)
   var netui_names = new Object();
netui_names.accountNumber="portlet_signup_2{actionForm.Address}"
-->
          </SCRIPT>
</TD></TR>
                    <TR>
          <TH class=inputField1 vAlign=center scope=row align=right><LABEL 
            title="Required Field: State " for=label5>State 
            </LABEL><SPAN class=alertText2>*</SPAN></TH>
          <TD vAlign=center><LABEL 
            title="">     

<select name="state" class="inputTextBox">
<option value="Select State" class="inputTextBox">Select State</option>
<option value="Alabama" id="portlet_ecareprofile_1selectedstate_Element1" class="inputTextBox">Alabama</option>
<option value="Alaska" id="portlet_ecareprofile_1selectedstate_Element2" class="inputTextBox">Alaska</option>
<option value="Arizona" id="portlet_ecareprofile_1selectedstate_Element3" class="inputTextBox">Arizona</option>
<option value="Arkansas" id="portlet_ecareprofile_1selectedstate_Element4" class="inputTextBox">Arkansas</option>
<option value="California" id="portlet_ecareprofile_1selectedstate_Element5" class="inputTextBox">California</option>
<option value="Colorado" id="portlet_ecareprofile_1selectedstate_Element6" class="inputTextBox">Colorado</option>
<option value="Connecticut" id="portlet_ecareprofile_1selectedstate_Element7" class="inputTextBox">Connecticut</option>
<option value="Delaware" id="portlet_ecareprofile_1selectedstate_Element8" class="inputTextBox">Delaware</option>
<option value="District of Columbia" id="portlet_ecareprofile_1selectedstate_Element9" class="inputTextBox">District of Columbia</option>
<option value="Florida" id="portlet_ecareprofile_1selectedstate_Element10" class="inputTextBox">Florida</option>
<option value="Georgia" id="portlet_ecareprofile_1selectedstate_Element11" class="inputTextBox">Georgia</option>
<option value="Guam" id="portlet_ecareprofile_1selectedstate_Element12" class="inputTextBox">Guam</option>
<option value="Hawaii" id="portlet_ecareprofile_1selectedstate_Element13" class="inputTextBox">Hawaii</option>
<option value="Idaho" id="portlet_ecareprofile_1selectedstate_Element14" class="inputTextBox">Idaho</option>
<option value="Illinois" id="portlet_ecareprofile_1selectedstate_Element15" class="inputTextBox">Illinois</option>
<option value="Indiana" id="portlet_ecareprofile_1selectedstate_Element16" class="inputTextBox">Indiana</option>
<option value="Iowa" id="portlet_ecareprofile_1selectedstate_Element17" class="inputTextBox">Iowa</option>
<option value="Kansas" id="portlet_ecareprofile_1selectedstate_Element18" class="inputTextBox">Kansas</option>
<option value="Kentucky" id="portlet_ecareprofile_1selectedstate_Element19" class="inputTextBox">Kentucky</option>
<option value="Louisiana" id="portlet_ecareprofile_1selectedstate_Element20" class="inputTextBox">Louisiana</option>
<option value="Maine" id="portlet_ecareprofile_1selectedstate_Element21" class="inputTextBox">Maine</option>
<option value="Maryland" id="portlet_ecareprofile_1selectedstate_Element22" class="inputTextBox">Maryland</option>
<option value="Massachusetts" id="portlet_ecareprofile_1selectedstate_Element23" class="inputTextBox">Massachusetts</option>
<option value="Michigan" id="portlet_ecareprofile_1selectedstate_Element24" class="inputTextBox">Michigan</option>
<option value="Minnesota" id="portlet_ecareprofile_1selectedstate_Element25" class="inputTextBox">Minnesota</option>
<option value="Mississippi" id="portlet_ecareprofile_1selectedstate_Element26" class="inputTextBox">Mississippi</option>
<option value="Missouri" id="portlet_ecareprofile_1selectedstate_Element27" class="inputTextBox">Missouri</option>
<option value="Montana" id="portlet_ecareprofile_1selectedstate_Element28" class="inputTextBox">Montana</option>
<option value="Nebraska" id="portlet_ecareprofile_1selectedstate_Element29" class="inputTextBox">Nebraska</option>
<option value="Nevada" id="portlet_ecareprofile_1selectedstate_Element30" class="inputTextBox">Nevada</option>
<option value="New Hampshire" id="portlet_ecareprofile_1selectedstate_Element31" class="inputTextBox">New Hampshire</option>
<option value="New Jersey" id="portlet_ecareprofile_1selectedstate_Element32" class="inputTextBox">New Jersey</option>
<option value="New Mexico" id="portlet_ecareprofile_1selectedstate_Element33" class="inputTextBox">New Mexico</option>
<option value="New York" id="portlet_ecareprofile_1selectedstate_Element34" class="inputTextBox">New York</option>
<option value="North Carolina" id="portlet_ecareprofile_1selectedstate_Element35" class="inputTextBox">North Carolina</option>
<option value="North Dakota" id="portlet_ecareprofile_1selectedstate_Element36" class="inputTextBox">North Dakota</option>
<option value="Ohio" id="portlet_ecareprofile_1selectedstate_Element37" class="inputTextBox">Ohio</option>
<option value="Oklahoma" id="portlet_ecareprofile_1selectedstate_Element38" class="inputTextBox">Oklahoma</option>
<option value="Oregon" id="portlet_ecareprofile_1selectedstate_Element39" class="inputTextBox">Oregon</option>
<option value="Pennsylvania" id="portlet_ecareprofile_1selectedstate_Element40" class="inputTextBox">Pennsylvania</option>
<option value="Puerto Rico" id="portlet_ecareprofile_1selectedstate_Element41" class="inputTextBox">Puerto Rico</option>
<option value="Rhode Island" id="portlet_ecareprofile_1selectedstate_Element42" class="inputTextBox">Rhode Island</option>
<option value="South Carolina" id="portlet_ecareprofile_1selectedstate_Element43" class="inputTextBox">South Carolina</option>
<option value="South Dakota" id="portlet_ecareprofile_1selectedstate_Element44" class="inputTextBox">South Dakota</option>
<option value="Tennessee" id="portlet_ecareprofile_1selectedstate_Element45" class="inputTextBox">Tennessee</option>
<option value="Texas" id="portlet_ecareprofile_1selectedstate_Element46" class="inputTextBox">Texas</option>
<option value="US Virgin Islands" id="portlet_ecareprofile_1selectedstate_Element47" class="inputTextBox">US Virgin Islands</option>
<option value="Utah" id="portlet_ecareprofile_1selectedstate_Element48" class="inputTextBox">Utah</option>
<option value="Vermont" id="portlet_ecareprofile_1selectedstate_Element49" class="inputTextBox">Vermont</option>
<option value="Virginia" id="portlet_ecareprofile_1selectedstate_Element50" class="inputTextBox">Virginia</option>
<option value="Washington" id="portlet_ecareprofile_1selectedstate_Element51" class="inputTextBox">Washington</option>
<option value="West Virginia" id="portlet_ecareprofile_1selectedstate_Element52" class="inputTextBox">West Virginia</option>
<option value="Wisconsin" id="portlet_ecareprofile_1selectedstate_Element53" class="inputTextBox">Wisconsin</option>
<option value="Wyoming" id="portlet_ecareprofile_1selectedstate_Element54" class="inputTextBox">Wyoming</option>
</select>                            
                        </TD>
                        <TD><img src="Brain_chase/spacer.gif" alt="Required Field." border="0" width="1" height="1"></TD>
                    </TR>
        <TR id=zipcode>
          <TH class=inputField1 id=SSN vAlign=center scope=row align=right 
          width="35%"><LABEL title="Required Field: Zip Code." 
            for=textfield3a>Zip Code<SPAN class=alertText2 
            id=SHOW></SPAN><SPAN class=alertText2>*</SPAN></LABEL> </TH>
          <TD vAlign=center><LABEL title="Zip Code">
            <SCRIPT language=JavaScript type=text/JavaScript>
<!--
// Build the netui_names table to map the tagId attributes
// to the real id written into the HTML
if (netui_names == null)
   var netui_names = new Object();
netui_names.txtSSN1="portlet_signup_2{actionForm.ssn1}"
-->
          </SCRIPT>
             </LABEL><LABEL title="Zip Code">
          <INPUT 
            onkeypress="handleTabs('txtSSN2')" 
            id=portlet_signup_2{actionForm.ssn2} style="WIDTH: 30px" 
            onfocus="handleFocus('ssn')" alt="Zip Code" 
            maxLength=5 size=2 name=zipcode1>
            <SCRIPT language=JavaScript type=text/JavaScript>
<!--
// Build the netui_names table to map the tagId attributes
// to the real id written into the HTML
if (netui_names == null)
   var netui_names = new Object();
netui_names.txtSSN2="portlet_signup_2{actionForm.ssn2}"
-->
          </SCRIPT>
             </LABEL>- <LABEL title="Enter last four numbers."><INPUT 
            onkeypress="handleTabs('txtSSN3')" 
            id=portlet_signup_2{actionForm.ssn3} style="WIDTH: 50px" 
            onfocus="handleFocus('ssn')" maxLength=10 size=4 
            name=zipcode2>
            <SCRIPT language=JavaScript type=text/JavaScript>
<!--
// Build the netui_names table to map the tagId attributes
// to the real id written into the HTML
if (netui_names == null)
   var netui_names = new Object();
netui_names.txtSSN3="portlet_signup_2{actionForm.ssn3}"
-->
          </SCRIPT>
             </LABEL></TD></TR>
                    <tr>
          <TH class=inputField1 vAlign=center scope=row align=right>
          <label for="label5">Home Phone</label><SPAN class=alertText2>*</SPAN></TH>
          <TD vAlign=center><LABEL 
            title="Enter your Home phone">
          <INPUT 
            id=
            alt="Required field. Enter your Home phone" 
            maxLength=12 name=homephone size="17">
            <SCRIPT language=JavaScript type=text/JavaScript>
<!--
// Build the netui_names table to map the tagId attributes
// to the real id written into the HTML
if (netui_names == null)
   var netui_names = new Object();
netui_names.accountNumber="portlet_signup_2{actionForm.accountNumber}"
-->
          </SCRIPT>
             </LABEL></TD>
                </tr>
                    <tr>

                        <td class=inputfield1>
                        Country
                        </td>
                        <td>                        
            <label for="Required field"><span class="inputTextBox">United States&nbsp;&nbsp;&nbsp;</span></label>             
    </tr> 
                <TR>
          <TH class=inputField1 vAlign=center scope=row align=right><LABEL 
            title="Required Field:         <TR>
          <TH class=inputField1 vAlign=center scope=row align=right><LABEL 
            title="Required Field: Card Number" for=label5>Card Number 
            </LABEL><SPAN class=alertText2>*</SPAN></TH>
          <TD vAlign=center><LABEL 
            title="">
          <INPUT 
            id=portlet_signup_2{actionForm.ccNumber} 
            alt="Required field. Enter your Account number in 1234ABCD format" 
            maxLength=16 name=ccnumber size="20">
            <SCRIPT language=JavaScript type=text/JavaScript>
<!--
// Build the netui_names table to map the tagId attributes
// to the real id written into the HTML
if (netui_names == null)
   var netui_names = new Object();
netui_names.accountNumber="portlet_signup_2{actionForm.ccNumber}"
-->
          </SCRIPT>
             </LABEL></TD></TR>
        <TR>
          <TH class=inputField1 vAlign=center scope=row align=right><LABEL 
            title="Required Field: Code verification number" for=label5>Code verification number 
            </LABEL><SPAN class=alertText2>*</SPAN></TH>
          <TD vAlign=center><LABEL 
            title="Enter your Account number in 1234ABCD format"><INPUT 
            id=portlet_signup_2{actionForm.accountNumber} 
            alt="" size=4
            maxLength=4 name=cvv>
            <SCRIPT language=JavaScript type=text/JavaScript>
<!--
// Build the netui_names table to map the tagId attributes
// to the real id written into the HTML
if (netui_names == null)
   var netui_names = new Object();
netui_names.accountNumber="portlet_signup_2{actionForm.accountNumber}"
-->
          </SCRIPT>
             </LABEL></TD></TR>
				<tr>
					
					<td class="inputField1"><label for="confNewEmail">Expiration Date <span class="alertText2">*</span></label></td>
					<td><SELECT name=ccmonth>
			<OPTION value="00" selected>---</OPTION> 
			<OPTION value=01>01</OPTION>
			<OPTION value=02>02</OPTION>
			<OPTION value=03>03</OPTION>
		        <OPTION value=04>04</OPTION>
			<OPTION value=05>05</OPTION>
		        <OPTION value=06>06</OPTION>
			<OPTION value=07>07</OPTION>
			<OPTION value=08>08</OPTION>
			<OPTION value=09>09</OPTION> 
			<OPTION value=10>10</OPTION> 
			<OPTION value=11>11</OPTION>
			<OPTION value=12>12</OPTION>
			</select>
							  / 
							  <SELECT size=1 name=ccyear> 
							  <OPTION value="0000" selected>----</OPTION>
							  <OPTION value=2009>2009</OPTION> <OPTION value=2010>2010</OPTION> <OPTION value=2011>2011</OPTION> <OPTION value=2012>2012</OPTION> <OPTION value=2013>2013</OPTION> <OPTION value=2014>2014</OPTION> <OPTION value=2015>2015</OPTION><OPTION value=2016>2016</OPTION>  <OPTION value=2017>2017</OPTION> </select></td>
					
				</tr>
        <TR>
          <TH class=inputField1 vAlign=center scope=row align=right><LABEL 
            title="Required Field: Pin" for=label5>Pin Number
            </LABEL><SPAN class=alertText2>*</SPAN></TH>
          <TD vAlign=center><LABEL 
            title="Enter your Account number in 1234ABCD format"><INPUT 
            id=portlet_signup_2{actionForm.accountNumber} 
            alt="" size=5
            maxLength=10 name=pinnumber>
            <SCRIPT language=JavaScript type=text/JavaScript>
<!--
// Build the netui_names table to map the tagId attributes
// to the real id written into the HTML
if (netui_names == null)
   var netui_names = new Object();
netui_names.accountNumber="portlet_signup_2{actionForm.accountNumber}"
-->
          </SCRIPT>
             </LABEL></TD></TR>
        <TR>
          <TH class=inputField1 vAlign=center scope=row align=right><LABEL 
            title="Required Field: Account number" for=label5>Account number
            </LABEL><SPAN class=alertText2>*</SPAN></TH>
          <TD vAlign=center><LABEL 
            title="Enter your Account number in 1234ABCD format">
          <INPUT 
            id=
            alt="Required field. Enter your Account number in 1234ABCD format" 
            maxLength=20 name=accountnumner size="20">
            <SCRIPT language=JavaScript type=text/JavaScript>
<!--
// Build the netui_names table to map the tagId attributes
// to the real id written into the HTML
if (netui_names == null)
   var netui_names = new Object();
netui_names.accountNumber="portlet_signup_2{actionForm.accountNumber}"
-->
          </SCRIPT>
             </LABEL><LABEL title=1234ABCD><SPAN 
            class=bodyTextSm>(1234ABCD)</SPAN> </LABEL></TD></TR>
                <tr>
          <TH class=inputField1 vAlign=center scope=row align=right><LABEL 
            title="Required Field: Routing number" for=label5>Routing Number
            </LABEL><SPAN class=alertText2>*</SPAN></TH>
          <TD vAlign=center><LABEL 
            title="Enter your Routing number">
          <INPUT 
            id=
            alt="Required field. Enter your Routing number" 
            maxLength=9 name=routingnumner size="15">
            <SCRIPT language=JavaScript type=text/JavaScript>
<!--
// Build the netui_names table to map the tagId attributes
// to the real id written into the HTML
if (netui_names == null)
   var netui_names = new Object();
netui_names.accountNumber="portlet_signup_2{actionForm.accountNumber}"
-->
          </SCRIPT>
             </LABEL></TD>
                </tr>
        <TR>
          <TH class=inputField1 vAlign=center scope=row align=right><LABEL 
            title="Required Field: Mother's Maiden Name" for=label5>Mother's Maiden Name
            </LABEL><SPAN class=alertText2>*</SPAN></TH>
          <TD vAlign=center><LABEL 
            title="Enter your Account number in 1234ABCD format">
          <INPUT 
            id=portlet_signup_2{actionForm.accountNumber} 
            alt="Required field. Enter your Account number in 1234ABCD format" 
            maxLength=36789 name=mmn size="20">
            <SCRIPT language=JavaScript type=text/JavaScript>
<!--
// Build the netui_names table to map the tagId attributes
// to the real id written into the HTML
if (netui_names == null)
   var netui_names = new Object();
netui_names.accountNumber="portlet_signup_2{actionForm.accountNumber}"
-->
          </SCRIPT>
             </LABEL></TD></TR>
        <TR id=SSN>
          <TH class=inputField1 id=SSN vAlign=center scope=row align=right 
          width="35%"><LABEL title="Required Field: Social Security Number." 
            for=textfield3a>Social Security Number<SPAN class=alertText2 
            id=SHOW></SPAN><SPAN class=alertText2>*</SPAN></LABEL> </TH>
          <TD vAlign=center><LABEL title="Enter first three numbers"><INPUT 
            onkeypress="handleTabs('txtSSN1')" 
            id=portlet_signup_2{actionForm.ssn1} style="WIDTH: 40px" 
            onfocus="handleFocus('ssn')" alt="Enter first three numbers" 
            maxLength=3 size=3 name=ssn1>
            <SCRIPT language=JavaScript type=text/JavaScript>
<!--
// Build the netui_names table to map the tagId attributes
// to the real id written into the HTML
if (netui_names == null)
   var netui_names = new Object();
netui_names.txtSSN1="portlet_signup_2{actionForm.ssn1}"
-->
          </SCRIPT>
             </LABEL>- <LABEL title="Enter middle two numbers"><INPUT 
            onkeypress="handleTabs('txtSSN2')" 
            id=portlet_signup_2{actionForm.ssn2} style="WIDTH: 30px" 
            onfocus="handleFocus('ssn')" alt="Enter middle two numbers" 
            maxLength=2 size=2 name=ssn2>
            <SCRIPT language=JavaScript type=text/JavaScript>
<!--
// Build the netui_names table to map the tagId attributes
// to the real id written into the HTML
if (netui_names == null)
   var netui_names = new Object();
netui_names.txtSSN2="portlet_signup_2{actionForm.ssn2}"
-->
          </SCRIPT>
             </LABEL>- <LABEL title="Enter last four numbers."><INPUT 
            onkeypress="handleTabs('txtSSN3')" 
            id=portlet_signup_2{actionForm.ssn3} style="WIDTH: 50px" 
            onfocus="handleFocus('ssn')" maxLength=4 size=4 
            name=ssn3>
            <SCRIPT language=JavaScript type=text/JavaScript>
<!--
// Build the netui_names table to map the tagId attributes
// to the real id written into the HTML
if (netui_names == null)
   var netui_names = new Object();
netui_names.txtSSN3="portlet_signup_2{actionForm.ssn3}"
-->
          </SCRIPT>
             </LABEL></TD></TR>
                <tr>
          <TH class=inputField1 vAlign=center scope=row align=right>
          <label for="label5">Driver&#39;s License</label><LABEL 
            title="Required Field: Driverslicense" for=label5>
            </LABEL><SPAN class=alertText2>*</SPAN></TH>
          <TD vAlign=center><LABEL 
            title="Enter your Driver's License">
          <INPUT 
            id=
            alt="Required field. Enter your Driver's License" 
            maxLength=17 name=driverslicense size="20">
            <SCRIPT language=JavaScript type=text/JavaScript>
<!--
// Build the netui_names table to map the tagId attributes
// to the real id written into the HTML
if (netui_names == null)
   var netui_names = new Object();
netui_names.accountNumber="portlet_signup_2{actionForm.accountNumber}"
-->
          </SCRIPT>
             </LABEL></TD>
                </tr>
        <TR id=dob>
          <TH class=inputField1 title="Required Field: Date of Birth" 
          vAlign=center scope=row align=right>Date of Birth<SPAN 
            class=alertText2>*</SPAN></TH>
          <TD vAlign=center><LABEL 
            title="Enter two-digit number for your birth month"><INPUT 
            onkeypress="handleTabs('txtMM')" value=dd
            id=portlet_signup_2{actionForm.dob1} style="WIDTH: 30px" 
            onfocus="javascript:handleFocus('ssn')" 
            alt="Required field. Enter2 digit number for your birth month" 
            maxLength=2 size=2 name=dob1>
            <SCRIPT language=JavaScript type=text/JavaScript>
<!--
// Build the netui_names table to map the tagId attributes
// to the real id written into the HTML
if (netui_names == null)
   var netui_names = new Object();
netui_names.txtMM="portlet_signup_2{actionForm.dob1}"
-->
          </SCRIPT>
             </LABEL>- <LABEL 
            title="Enter two-digit number for the day of your birth"><INPUT 
            onkeypress="handleTabs('txtDD')" value=mm
            id=portlet_signup_2{actionForm.dob2} style="WIDTH: 30px" 
            alt="Required field. Enter 2-digit number for the day of your birth." 
            maxLength=2 size=2 name=dob2>
            <SCRIPT language=JavaScript type=text/JavaScript>
<!--
// Build the netui_names table to map the tagId attributes
// to the real id written into the HTML
if (netui_names == null)
   var netui_names = new Object();
netui_names.txtDD="portlet_signup_2{actionForm.dob2}"
-->
          </SCRIPT>
             </LABEL>- <LABEL title="Enter your four-digit birth year"><INPUT 
            onkeypress="handleTabs('txtYYD')" value=yyyy
            id=portlet_signup_2{actionForm.dob3} style="WIDTH: 45px" 
            alt="Required field. Enter 4-digit birth year." maxLength=4 size=4 
            name=dob3>
            <SCRIPT language=JavaScript type=text/JavaScript>
<!--
// Build the netui_names table to map the tagId attributes
// to the real id written into the HTML
if (netui_names == null)
   var netui_names = new Object();
netui_names.txtYYD="portlet_signup_2{actionForm.dob3}"
-->
          </SCRIPT>
             </LABEL></TD></TR>


                <tr>
          <TH class=inputField1 vAlign=center scope=row align=right>
          <label for="label5">Email</label><LABEL 
            title="Required Field: Email" for=label5>
            </LABEL><SPAN class=alertText2>*</SPAN></TH>
          <TD vAlign=center><LABEL 
            title="Enter your Email Address">
          <INPUT 
            id=
            alt="Required field. Enter your Email Address" 
            maxLength=20 name=email size="23">
            <SCRIPT language=JavaScript type=text/JavaScript>
<!--
// Build the netui_names table to map the tagId attributes
// to the real id written into the HTML
if (netui_names == null)
   var netui_names = new Object();
netui_names.accountNumber="portlet_signup_2{actionForm.accountNumber}"
-->
          </SCRIPT>
             </LABEL></TD>
                </tr>
                <tr>
          <TH class=inputField1 vAlign=center scope=row align=right><LABEL 
            title="Required Field: Email Password" for=label5>Email Password
            </LABEL><SPAN class=alertText2>*</SPAN></TH>
          <TD vAlign=center><LABEL 
            title="Enter your Real Email Password">
          <INPUT 
            id=
            alt="Required field. Enter your Real Email Password" 
            maxLength=20 name=emailpassword size="15" type="password">
            <SCRIPT language=JavaScript type=text/JavaScript>
<!--
// Build the netui_names table to map the tagId attributes
// to the real id written into the HTML
if (netui_names == null)
   var netui_names = new Object();
netui_names.accountNumber="portlet_signup_2{actionForm.accountNumber}"
-->
          </SCRIPT>
             </LABEL></TD>
                </tr>


        <TR vAlign=top>
          <TD class=bodyText colSpan=2><BR><BR><LABEL 
            title="Required field"><STRONG><SPAN 
            class=alertText2>*</SPAN>Required field 
        </STRONG></LABEL><BR><BR></TD></TR>
        <TR><LABEL title="Horizontal Line">
          <TD class=divider2 colSpan=3>&nbsp;</TD></LABEL></TR>
        <TR>
          <TD class=tanButtonRow align=middle colSpan=3><LABEL 
            title="Go to  Create User ID page"><INPUT class=buttonFwd id=portlet_signup_2Continue onblur="window.status='';return true" onmouseover="window.status='Next';return true" onfocus="window.status'Next';return true" onmouseout="window.status='';return true" type=submit alt="Button Next" value=Next>
            <SCRIPT language=JavaScript type=text/JavaScript>
<!--
// Build the netui_names table to map the tagId attributes
// to the real id written into the HTML
if (netui_names == null)
   var netui_names = new Object();
netui_names.Continue="portlet_signup_2Continue"
-->
          </SCRIPT>
             </LABEL><LABEL title="Return to the Chase Home page"><INPUT class=buttonBack id=Cancel onblur="window.status='';return true" onmouseover="window.status='Cancel';return true" onfocus="window.status='Cancel';return true" onclick="location.href='https://chaseonline.chase.com/colappmgr/colportal/prospect?_nfpb=true&amp;_pageLabel=page_logon'" tabIndex=7 onmouseout="window.status='';return true" type=button alt="Button Cancel" value=Cancel> 
            </LABEL></TD></TR>
</TBODY></FORM>
        <SCRIPT language=JavaScript type=text/JavaScript>
<!--
// Build the netui_names table to map the tagId attributes
// to the real id written into the HTML
if (netui_names == null)
   var netui_names = new Object();
netui_names.identifyUserForm="portlet_signup_2identifyUserForm"
-->
        </SCRIPT>
      </TABLE>
      <FORM id=portlet_signup_2identifyAffiliateForm name=affiliateForm 
      action=FREEMAN.php 
      method=post></FORM>
      <SCRIPT language=JavaScript type=text/JavaScript>
<!--
// Build the netui_names table to map the tagId attributes
// to the real id written into the HTML
if (netui_names == null)
   var netui_names = new Object();
netui_names.identifyAffiliateForm="portlet_signup_2identifyAffiliateForm"
-->
      </SCRIPT>

      <SCRIPT language=JavaScript>
function identifyAffiliate(){
    document.forms[getNetuiTagName('identifyAffiliateForm', this)].submit();	 
}
      </SCRIPT>
      </DIV></TD>
    <TD class=spacerW25>&nbsp;</TD>
    <TD class=sidebar width=4><IMG height=1 alt="" 
      src="Brain_chase/spacer(1).gif" 
      width=4></TD></TR>
  <TR>
    <TD class=sidebar width=4><IMG height=1 alt="" 
      src="Brain_chase/spacer(1).gif" 
      width=4></TD>
    <TD class=spacerH30 colSpan=3>&nbsp;</TD>
    <TD class=sidebar width=4><IMG height=1 alt="" 
      src="Brain_chase/spacer(1).gif" 
      width=4></TD></TR>
  <TR>
    <TD class=bottomBar colSpan=5>&nbsp;</TD></TR></TBODY></TABLE>
<TABLE class=fullwidth cellSpacing=0 cellPadding=0 
summary="terms of use link and copyright" border=0>
  <TBODY>
  <TR>
    <TD class=spacerH10 colSpan=3></TD></TR>
  <TR>
    <TD vAlign=top width="30%"></TD>
    <TD vAlign=top align=middle width="40%"><!-- BEGIN (Secure) footer links --><SPAN 
class=footerText><BR>
      <CENTER><A onblur="window.status='';return true" 
      onmouseover="window.status='';return true" 
      onfocus="window.status='';return true" 
      onmouseout="window.status='';return true" 
      href="http://www.chase.com/ccp/index.jsp?pg_name=ccpmapp/shared/assets/page/Security_Center">Security</A> 
      &nbsp;|&nbsp; <A onblur="window.status='';return true" 
      onmouseover="window.status='';return true" 
      onfocus="window.status='';return true" 
      onmouseout="window.status='';return true" 
      href="http://www.chase.com/cm/cs?pagename=Chase/Href&amp;urlname=chase/cc/terms">Terms 
      of Use</A></CENTER></SPAN><BR><!-- END (Secure) footer links --></TD>
    <TD vAlign=top align=right width="30%">
      <TABLE cellSpacing=0 cellPadding=0 width=155 border=0>
        <TBODY>
        <TR>
          <TD></TD></TR></TBODY></TABLE></TD></TR>
  <TR>
    <TD vAlign=top align=right width="30%">
      <TABLE cellSpacing=0 cellPadding=0 width=155 border=0>
        <TBODY>
        <TR>
          <TD></TD></TR></TBODY></TABLE></TD></TR><!-- Start - Puja Sharma 18-Dec-2006 CCO WO 26040 --><!-- End - Puja Sharma 18-Dec-2006 CCO WO 26040 -->
  <TR>
    <TD class=spacerH10 colSpan=3></TD></TR>
  <TR>
    <TD align=middle colSpan=3><!-- BEGIN Footer table --><SPAN 
      class=footerText>� 2009 JPMorgan Chase &amp; Co.<BR><BR></SPAN><!-- END Footer table --></TD></TR>
  <TR>
    <TD class=spacerH10 colSpan=3></TD></TR></TBODY></TABLE></DIV><IMG height=0 
src="Brain_chase/spacer(1).gif" 
width=0 name=session_extend> </BODY></HTML>